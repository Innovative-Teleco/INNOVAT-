<?php 
session_start();
require('../../db.php'); 
include('../../inc/func1.php');
include('../../inc/gravatar.php');
include('../../inc/logo.php');
include('../../inc/coinpayments.inc.php');
include('../../inc/query_processor.php');
?> 
<?php include('../../inc/header2.php');?>
        <!-- ============================================================== -->
        <!-- end navbar -->
        <!-- ============================================================== -->
    
        <!-- ============================================================== -->
        <!-- left sidebar -->
        <!-- ============================================================== -->
        <?php include('../../inc/nav3.php'); ?>
        <!-- ============================================================== -->
        <!-- end left sidebar -->
        <!-- ============================================================== -->
        <!-- ============================================================== -->
        <!-- wrapper  -->
        <!-- ============================================================== -->
        <div class="dashboard-wrapper">
            <div class="dashboard-ecommerce">
                <div class="container-fluid dashboard-content ">
                    <!-- ============================================================== -->
                  
                    <!-- pageheader  -->
                  
                    <div class="ecommerce-widget">

                        <div class="row"></div>
                        <div class="row">
                            <!-- ============================================================== -->
                      
                         
                            <div class="col-xl-9 col-lg-12 col-md-6 col-sm-12 col-12">
                            
                                <div class="card">
                                          
                                    <h5 class="card-header"></h5>
                                    <div class="card-body">
                                    <?php
							
							if(isset($_GET['ref'])){
								       echo'<div class="alert alert-success">
										<button type="button" class="close" data-dismiss="alert">×</button>
										<strong>Transaction successful</strong>  
									</div>'; 
									
									echo '<script>
									setTimeout(function(){ window.location.href="../../dashboard.php" }, 3000);</script>';
									      
								        }
								        
										$username = $_SESSION['user'];
										$amount = $_SESSION['amt'];
										$network = $_SESSION['carier'];
										$phone = $_SESSION['phone'];
										$requestId = $_SESSION['transid'];
										$iuc = $_SESSION['iuc'];
										$plan = $_SESSION['plan'];
										$CustomerName = $_SESSION['customer'];
										$CustomerAddress = $_SESSION['address'];
										$CustomerPhone = $_SESSION['Customer_Phone'];
										$type = $_SESSION['type'];
										$variation_code = $_SESSION['variation_code'];
										
											$valu = $iuc;
										
					$trans = mysqli_query($conn,"SELECT * FROM transactions WHERE ref='$requestId' ");					
					$rowTrans = mysqli_fetch_array($trans);					
										
								$txtadmin = "08084121526";		
										// replace comma
						$str1 = $amount;
						$xamount = str_replace( ',', '', $str1);
						
						
		$query_com = mysqli_query($conn,"SELECT * FROM billing");
	$rate = mysqli_fetch_array($query_com);
	
	$access = 'free';
	$dstv = $rate['dstv'];
	$gotv = $rate['gotv'];
	$startimes = $rate['startimes'];
	$ikeja = $rate['IkejaElectric'];
		$eko = $rate['EkoElectric'];
		$kano = $rate['Kedc'];
		$jos = $rate['JosElectric'];
		$phed = $rate['Phed'];
		$ibedc = $rate['Ibedc'];
		$smile = $rate['smile'];
		
		
		if($network === 'gotv' && $level !== $access ){
		
		$per = $gotv;	
		
		$charge = 0;
			
			}elseif($network === 'dstv' && $level !== $access){
				
			$per = $dstv;
			
			$charge = 0;	
				}elseif($network === 'startimes' && $level !== $access){
					
				$per = $startimes;	
				
				$charge = 0;
				
					}elseif($network === 'ikeja-electric' && $level !== $access){
						
						$per = $ikeja;
						
						$charge = 0;
						
			}elseif($network === 'portharcourt-electric' && $level !== $access){	
										
				$per = $phed;
				
				$charge = 0;	
					}
				elseif($network === 'ibadan-electric' && $level !== $access){
						
					$per = $ibedc;	
					
					$charge = 0;
						}
						elseif($network === 'kano-electric' && $level !== $access){
							
						$per = $kano;
						$charge = 0;		
							
							}
						elseif($network === 'jos-electric' && $level !== $access){
								
							$per = $jos;
							$charge = 0;	
								}
						elseif($network === 'eko-electric' && $level !== $access){
								
							$per = $eko;
							$charge = 0;	
								
							}elseif($network === 'smile-direct' && $level !== $access){
							    
							 $per = $smile;
							$charge = 0;  
							}
							
							
							else{
							
						// Regular Charge
						
						
	$dstvR = $Regubil['dstv'];
	$gotvR = $Regubil['gotv'];
	$startimesR = $Regubil['startimes'];
	$ikejaR = $Regubil['IkejaElectric'];
		$ekoR = $Regubil['EkoElectric'];
		$kanoR = $Regubil['Kedc'];
		$josR = $Regubil['JosElectric'];
		$phedR = $Regubil['Phed'];
		$ibedcR = $Regubil['Ibedc'];
		$smileR = $Regubil['smile'];				
								
					if($network === 'gotv' && $level == $access ){
		
		$per = $gotvR;	
		
		$charge = $Regubil['conv'];
			
			}elseif($network === 'dstv' && $level == $access){
				
			$per = $dstvR;
			
			$charge = $Regubil['conv'];	
				}elseif($network === 'startimes' && $level == $access){
					
				$per = $startimesR;	
				
				$charge = $Regubil['conv'];
				
					}elseif($network === 'ikeja-electric' && $level == $access){
						
						$per = $ikejaR;
						
						$charge = $Regubil['conv'];
						
			}elseif($network === 'portharcourt-electric' && $level == $access){	
										
				$per = $phedR;
				
				$charge = $Regubil['conv'];	
					}
				elseif($network === 'ibadan-electric' && $level == $access){
						
					$per = $ibedcR;	
					
					$charge = $Regubil['conv'];
						}
						elseif($network === 'kano-electric' && $level == $access){
							
						$per = $kanoR;
						$charge = $Regubil['conv'];		
							
							}
						elseif($network === 'jos-electric' && $level == $access){
								
							$per = $josR;
							$charge = $Regubil['conv'];	
								}
						elseif($network === 'eko-electric' && $level == $access){
								
							$per = $ekoR;
							$charge = $Regubil['conv'];	
								
							}elseif($network === 'smile-direct' && $level == $access){
							    
							 $per = $smileR;
							$charge = $Regubil['conv'];  
							}
							
							
							else{
							
							
							$per = 0;	
							$charge = 100;
								
								}				
								
								
								}	
						
						
								
								
								
					
					if($network === 'gotv' ){
	
		$affpay = $afi['gotv'];
		$product = "GOTV Payment";
		$img = "Gotv-Payment.jpg";
			
			}elseif($network === 'dstv'){
			
			$affpay = $afi['dstv'];
			
			$product = "DSTV Payment";
			
			$img = "Pay-DSTV-Subscription.jpg";
				
			}elseif($network === 'startimes'){
					
					$affpay = $afi['startimes'];
					
					$product = "Startimes Payment";
					
					$img = "Startimes-Subscription.jpg";
				
						}
						
						
						elseif($network === 'portharcourt-electric'){
					
					$affpay = $afi['Phed'];
					
					$product = "PortHarcourt Electric Payment - PHED";
					
					$img = "18112019141721Port-Harcourt-Electric.jpg";
				
						}
						
						elseif($network === 'ikeja-electric'){
					
					$affpay = $afi['IkejaElectric'];
					
					$product = "Ikeja Electric Payment - IKEDC";
					
					$img = "Ikeja-Electric-Payment-PHCN.jpg";
				
						}
						
						elseif($network === 'ibadan-electric'){
					
					$affpay = $afi['Ibedc'];
					
					$product = "Ibadan Electric Payment - IBEDC";
					
					$img = "Ikeja-Electric-Payment-PHCN.jpg";
				
						}
						
						
							elseif($network === 'eko-electric'){
					
					$affpay = $afi['EkoElectric'];
					
					$product = "Eko Electric Payment - EKEDC";
					
					$img = "Eko-Electric-Payment-PHCN.jpg";
				
						}
						
						
						elseif($network === 'jos-electric'){
					
					$affpay = $afi['JosElectric'];
					
					$product = "Jos Electric Payment - JED";
					
					$img = "Jos-Electric-JED.jpg";
				
						}
						
						
						elseif($network === 'kano-electric'){
					
					$affpay = $afi['Kedc'];
					
					$product = "Kano Electric Payment - KEDCO";
					
					$img = "Kano-Electricity-Distribution-Company-KEDCO-logo.png";
				
						}
						
						
						
						else{ $affpay = 0;	$product = "";}
						
						
				$payko = ($affpay/100)*$xamount;			
	
	
	$comi = ($per/100)*$xamount;
	$debit = $xamount-$comi;
						
						
										
						$chargeAmt = $debit + $charge;
						
						 $payable = $chargeAmt;
						
						$ShowName = '<tr>
                            <td width="30%">Customer Name</td>
                            <td id="mainService"> '.$CustomerName.'  </td>
                        </tr>
                        
                        ';
                      
							if($network === 'gotv'){
							$decoder = "IUC Number";
							$pnt = $plan;
							if(!is_null($CustomerName)){
							
							$customer = $ShowName;
							
							}else{$customer = "";}
							}elseif($network === 'dstv'){
								
								$pnt = $plan;
								$decoder = "SmartCard No";
								
								if(!is_null($CustomerName)){
								$customer = $ShowName;
							   		}else{$customer = "";}
								
								}
								
								elseif($network === 'portharcourt-electric'){
								
								$pnt = "Port Harcourt Electricity - PHED";
								$decoder = "Meter Number";
								
								if(!is_null($CustomerName)){
								$customer = $ShowName;
							   		}else{$customer = "";}
								
								}
								
								elseif($network === 'eko-electric'){
								
								$pnt = "Eko Electricity - EKEDC";
								$decoder = "Meter Number";
								
								if(!is_null($CustomerName)){
								$customer = $ShowName;
							   		}else{$customer = "";}
								
								}
								
								elseif($network === 'jos-electric'){
								
								$pnt = "Jos Electricity - JED";
								$decoder = "Meter Number";
								
								if(!is_null($CustomerName)){
								$customer = $ShowName;
							   		}else{$customer = "";}
								
								}
								
								elseif($network === 'ikeja-electric'){
								
								$pnt = "Ikeja Electricity - IKEDC";
								$decoder = "Meter Number";
								
								if(!is_null($CustomerName)){
								$customer = $ShowName;
							   		}else{$customer = "";}
								
								}
								elseif($network === 'ibadan-electric'){
								
								$pnt = "Ibadan Electricity - IBEDC";
								$decoder = "Meter Number";
								
								if(!is_null($CustomerName)){
								$customer = $ShowName;
							   		}else{$customer = "";}
								
								}
								
								elseif($network === 'kano-electric'){
								
								$pnt = "Kano Electricity - KEDCO";
								$decoder = "Meter Number";
								
								if(!is_null($CustomerName)){
								$customer = $ShowName;
							   		}else{$customer = "";}
								
								}
								
								elseif($network === 'startimes'){
									$pnt = "Startimes $plan";
									$decoder = "SmartCard No";
									
									if(!is_null($CustomerName)){
										
									$customer = $ShowName;
										
									}else{$customer = "";}
									
									}elseif($network === 'smile-direct'){
									    
									     $img = "Smile-Payment.jpg";
										
										if($type !== 'voice'){
										
									$pnt = "Smile $plan";
									$decoder = "Smile Account No";
										
									if(!is_null($CustomerName)){
										
									$customer = $ShowName;
										
									}else{$customer = "";}
										
										}else{ 
										
										$pnt = "Smile $plan";
									$decoder = "Smile Voice Number";
										
									if(!is_null($CustomerName)){
										
									$customer = $ShowName;
										
									}else{$customer = "";}   }
										
										}
									
									else{
										
										if(!is_null($CustomerName)){
										
									$customer = $ShowName;
										
									}else{$customer = "";}
									
									$pnt = $_SESSION['plan'];	
									$decoder = "Meter Number";
										}
						
										
									if(isset($_POST['pay'])){
										
										$uid = mt_rand(784755,99893);	
											
										if($chargeAmt <= $bal){	
											$dat = date("d/m/Y");
											
											$token = uniqid();
											$stat = "pending";
											
			$ret = mysqli_query($conn,"SELECT * FROM transactions WHERE ref='$requestId' ");
		
		$da = mysqli_fetch_array($ret);
		$tref = $da['ref'];
		
		if($da['refer'] === $da['token']){	
		
		$qry_debit = "UPDATE users SET bal=bal-$chargeAmt WHERE email='$user'";
			$doDebit = $conn->query($qry_debit);							
											
include('../../inc/billpay.php');

if ($resp->description->Status === 'NETWORK ERROR'){
    
    $qry_reverse = "UPDATE users SET bal=bal+$chargeAmt WHERE email='$user'";
			$doRev = $conn->query( $qry_reverse);
			
	echo'<div class="alert alert-danger">
		<button type="button" class="close" data-dismiss="alert">×</button>
										<strong>NETWORK ERROR . Credit Reversed</strong> 
										
									</div>';		
}else{

if(is_null($resp->description->Token)){
	
	$qsel = "UPDATE transactions SET status='Completed',token='0',refer='N/A',channel='Wallet' WHERE ref='$tref' ";	
			$sav = $conn->query($qsel);
	
	if($resp->code ==='101'){
			
$affilqry = "UPDATE users SET refwallet=refwallet+$payko WHERE email='$affto'"; 
$maffi = $conn->query($affilqry);
$upen="UPDATE earnings SET alltime=alltime+$payko WHERE user='$affto'";
$qaffi = $conn->query($upen);

$qrSv = mysqli_query($conn,"INSERT INTO earnlog(transaction,amount,status,refby) VALUES('$product','$payko','Completed','$affto');");

echo'<div class="alert alert-info">
		<button type="button" class="close" data-dismiss="alert">×</button>
										<strong>Transaction Successful</strong> 
										
									</div>';
}else{ 

$qrfel = "UPDATE transactions SET status='Failed',action='Reverse',del='Delete' WHERE ref='$requestId'";
  			$Qrevs = $conn->query($qrfel);
 }	
											
	
	}else{
	    
	 if($resp->code ==='101'){   
	    
	echo'<div class="alert alert-success">
										<button type="button" class="close" data-dismiss="alert">×</button>
										<strong>Transaction Successful</strong> -
								
				Token:<strong>	'.$resp->description->Token.'</strong>, Units: <strong>'.$units.'</strong> Product: '.$resp->description->Token.' 
									</div>'; 
									
	 }else{$qrfel = "UPDATE transactions SET status='Failed',action='Reverse',del='Delete' WHERE ref='$requestId'";
  			$Qrevs = $conn->query($qrfel); }
	    
	    
	}	}			
											
				
			 
									
						include('../../inc/notification.php');			
								
					
									
					} else{echo'<div class="alert alert-danger">
										<button type="button" class="close" data-dismiss="alert">×</button>
										<strong>Error Occur: Please contact support@'.$_SERVER['SERVER_NAME'].'</strong>  
									</div>';  }										
 
										}
                                   else{echo'<div class="alert alert-warning">
										<button type="button" class="close" data-dismiss="alert">×</button>
										<strong>[ Insufficient Balance ]</strong>, please pay with ATM card or <a href="../../buy_credit.php">Click here to credit wallet </a> 
									</div>';  }    
                                        
								
                                }	
                                
                       
if(isset($_POST['cardpay'])){
						   
						 // payprocessor
 if($apib['activepay'] == 'paystack'){
include('../../inc/paystack-bill.php');
 }else{
	 
include('../../inc/flutterwave-bill.php');	 
	 }
					
} 
if($rowTrans['status'] !== 'Completed'){
										  
include('../../inc/confirm-transaction.php');  
										  
}else{
											  
include('../../inc/transaction-details.php');   
											  
}						 
?>
                       
                
                                        
                                  <script>
                           
						   function show9mobile() {
  var sourceOfPicture = "assets/images/9mobile.jpg";
  var img = document.getElementById('bigpic')
  img.src = sourceOfPicture.replace('90x90', '225x225');
  img.style.display = "block";
} 
                   
function showMTN() {
  var sourceOfPicture = "assets/images/mtn.jpg";
  var img = document.getElementById('bigpic')
  img.src = sourceOfPicture.replace('90x90', '225x225');
  img.style.display = "block";
} 

function showAirtel() {
  var sourceOfPicture = "assets/images/airtel.jpg";
  var img = document.getElementById('bigpic')
  img.src = sourceOfPicture.replace('90x90', '225x225');
  img.style.display = "block";
} 

function showGlo() {
  var sourceOfPicture = "assets/images/glo.jpg";
  var img = document.getElementById('bigpic')
  img.src = sourceOfPicture.replace('90x90', '225x225');
  img.style.display = "block";
} 
                    
                                  </script>
                                        
                                    </div>
                                </div>
                            </div>
                            <!-- ============================================================== -->
                            <!-- end recent orders  -->
<script>
							 
							 function Comma(Num)
 {
       Num += '';
       Num = Num.replace(/,/g, '');

       x = Num.split('.');
       x1 = x[0];

       x2 = x.length > 1 ? '.' + x[1] : '';

       
         var rgx = /(\d)((\d{3}?)+)$/;

       while (rgx.test(x1))

       x1 = x1.replace(rgx, '$1' + ',' + '$2');
     
       return x1 + x2;       
        
 }
 
 
 
 function yesnoCheck() {
    if (document.getElementById('yescard').checked) {
        document.getElementById('ifYes').style.visibility = 'visible';
    }
    
     if (document.getElementById('yescash').checked) {
        document.getElementById('ifYes').style.visibility = 'visible';
    }
    
     if (document.getElementById('yesbitcoin').checked) {
        document.getElementById('ifYes').style.visibility = 'visible';
    }
    
    

}



                            </script> 
                            <!-- ============================================================== -->
                            
                             <script>
// Set the date we're counting down to
var countDownDate = new Date("Jan 5, 2021 15:37:25").getTime();

// Update the count down every 1 second
var x = setInterval(function() {

  // Get today's date and time
  var now = new Date().getTime();

  // Find the distance between now and the count down date
  var distance = countDownDate - now;

  // Time calculations for days, hours, minutes and seconds
  var days = Math.floor(distance / (1000 * 60 * 60 * 0));
  var hours = Math.floor((distance % (1000 * 60 * 60 * 1)) / (1000 * 60 * 60));
  var minutes = Math.floor((distance % (1000 * 60 * 30)) / (1000 * 60));
  var seconds = Math.floor((distance % (1000 * 60)) / 1000);

  // Display the result in the element with id="demo"
  document.getElementById("timing").innerHTML =  hours + "h "
  + minutes + "m " + seconds + "s ";

  // If the count down is finished, write some text
  if (distance < 0) {
    clearInterval(x);
    document.getElementById("timer").innerHTML = "EXPIRED";
  }
}, 1000);
</script>
                            <!-- ============================================================== -->
                            <!-- customer acquistion  -->
                            <!-- ============================================================== -->
                            <div class="col-xl-3 col-lg-6 col-md-6 col-sm-12 col-12">
                                <div class="card">
                                    <h5 class="card-header">Account Status</h5>
                                    <div class="card-body">
                                   <div class="d-inline-block">
                                        <h5 class="text-muted">Current Balance</h5>
                                        <h2 class="mb-0"> &#x20A6;<?php echo number_format($bal,2,'.',',');?></h2>
                                    </div>
                                    <div class="float-right icon-circle-medium  icon-box-lg  bg-brand-light mt-1">
                                        <i class="fa fa-money-bill-alt fa-fw fa-sm text-brand"></i>
                                    </div>
                                   
                                    </div>
                                </div>
                                
                                <div class="card">
                                <div class="card-body">
                                    <div class="d-inline-block">
                                        <h5 class="text-muted">Affiliate Link:</h5>
                                        <p class="mb-0"> <?php echo $data['reflink'];echo $data['refid'];?></p>
                                        
                                    </div>
                                    <div class="float-left"><p class="text-muted"><strong>Total Referred:</strong> <?php echo $data['refcount']; ?> <br> 
                                    
                                   <strong> Earning:</strong> &#x20A6;<?php echo number_format($data['refwallet'],2,'.',','); ?>
                                    </p> </div>
                                    
                                    
                                    <div class="float-right icon-circle-medium  icon-box-lg  bg-primary-light mt-1">
                                        
                                        <i class="fa fa-users fa-fw fa-sm text-primary"></i>
                                    </div>
                                </div>
                            </div>
                            </div>
                            <!-- ============================================================== -->
                            
                            
                            
                            <!-- end customer acquistion  -->
                      <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                        <div class="card">
                            <h5 class="card-header">Recent Transactions</h5>
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table class="table table-striped table-bordered first">
                                        <thead>
                                            <tr>
                                                <th>Transaction ID</th>
                                                
                                                <th>Amount</th>
                                                <th>Status</th>
                                                <th>Date</th>
                                               
                                            </tr>
                                        </thead>
                                        <tbody>
                                         <?php 
							$sql_trans = "SELECT * FROM transactions WHERE email='$user' ORDER BY `serial` DESC LIMIT 3 ";
									
$Show_trans = $conn->query($sql_trans);
										
										while($trow = $Show_trans->fetch_assoc())
											
											{
										
											?>
                                            <tr>
                                           
                                                <td><?php echo $trow['ref']; ?></td>
                                                
                                                <td><?php echo '&#x20A6;'.$trow['amount'].' ';?></td>
                                                 <td><?php echo $trow['status'];?></td>
                                                <td><?php echo $trow['date'];?></td>
                                                
                                            </tr>
                                           
                                           <?php } ?>
                                          
                                           
                                        </tbody>
                                        <tfoot>
                                            <tr>
                                                <th>Transaction ID</th>
                                                
                                                <th>Amount</th>
                                                <th>Status</th>
                                                <th>Date</th>
                                                
                                            </tr>
                                        </tfoot>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>      
                          
                            <!-- ============================================================== -->
                        </div>
                        <div class="row">
                            <!-- ============================================================== -->
              				                        <!-- product category  -->
                            <!-- ============================================================== -->
                            <!-- ============================================================== -->
                            <!-- end product category  -->
                          
  	<script type="text/javascript">
		//datepicker plugin
		//link	
		$('#sendWithPhoneBook').click(function(e){
		    $('#pb_groups').css('display','block');
		    e.preventDefault();
		});

		$("input[type=checkbox].grp_select").change( function() {
		    if($(this).is(":checked")){
		    	var bin = chkK();
		    		$("#grp_select_check").html('+'+bin+' Selected Phonebook Group Recepient(s)');	       	
			}else{
				var bin = chkK();
				if (bin > 0) {
					$("#grp_select_check").html('+'+bin+' Selected Phonebook Group Recepient(s)');
				}else{
					$("#grp_select_check").html('');
				}
			}
	  	});

		function countDest(){
			destcount = jQuery("#recipient").val();
			destcount = destcount.split(' ').join(',').split("\n").join(',').split(',,').join(',');
			// console.log(countUnit());
			destcount = destcount.split(',').length;
			if(destcount < 2) jQuery("#destcount").html(destcount+" recipient typed");
			else jQuery("#destcount").html(destcount+" recipients typed");
			$('#hiddenCount').html(destcount);
			// return destcount;
		}

		function chkK() {
			var val = [];
			$(':checkbox:checked').each(function(i){
	          val[i] = $(this).val();
	        });
	        return (val.length);
		}



		function countMsgsText(val){

			val = val.split("\n").join('??').split('{').join('??').split('}').join('??');

			val = val.split('\\').join('??').split('[').join('??').split(']').join('??');

			val = val.split('~').join('??').split('|').join('??').split('^').join('??');

			val = val.split('€').join('??').split('"').join('??').split("'").join('??');

			len = val.length;

			if(len<=160){

				jQuery('#paget').html('Page: '+Math.ceil(len/160));
				jQuery('#count').html(', Characters left: ' + (1+((160 - 1) * Math.ceil(len/160))-len) + ', Total Typed Characters: '+len);

				jQuery('#hiddenCount').html(Math.ceil(len/160)+' page');

			} else {
				jQuery('#paget').html('Page: '+Math.ceil(len/151));
				jQuery('#count').html(', Characters left: ' + (1+((151 - 1) * Math.ceil(len/151))-len) + ', Total Typed Characters: '+len);	

				jQuery('#hiddenCount').html(Math.ceil(len/151)+' pages');

			}

			countDest();

		}

		
		$('#recipient').keyup(function(){
			if (this.value.length > 0) {
				$('#destcount').css('display','block');
				countDest();
			}else{
				$('#destcount').css('display','none');
			}
		});
		
		function showUsage(messagesCount) {
			var x = jQuery('#paget').html()+", "+jQuery('#destcount').html()+"\nSend Message? Duplicate Numbers will be removed";
			return confirm(x);
		}
		function showUsageFree(messagesCount) {
			var x = jQuery('#paget').html()+", "+jQuery('#destcount').html()+"\nSend Message. You are using Free SMS Units and it ll contain an Advert?";
			return confirm(x);
		}
		$('#myForm input').on('change', function() {
		   var oname = ($('input[name="mode"]:checked', '#myForm').val()); 
		   // alert(oname);
		   if (oname =='sms') {
		   		$('#emailbox').css("display","none");
		   		$('#smsbox').css("display","block");
		   }else if(oname =='email'){
		   		$('#smsbox').css("display","none");
		   		$('#emailbox').css("display","block");
		   }
		});
		$('#form-field-select-1').on('change',function () {
			var selectVal = $('#form-field-select-1').val();
			if (selectVal == '4') {
				$('#date-range').css("display","none");
				$('#wallet-range').css("display","block");
			}else{
				$('#date-range').css("display","block");
				$('#wallet-range').css("display","none");
			}
		});
		</script>
		<script type="text/javascript">
	$(function() {
	    var scntDiv = $('#more-xtra');
	    var i = $('#more-xtra div').length + 1;
	    $('#addScnt').on('click', function() {
	    	// alert('ooooo');
	    	console.log(i);
	    	$('#addScnt').html('Add More Date');
	        $('<div id="extr" class="form-group"><label class="col-md-4 control-label">Schedule Date</label><div class="col-md-8"><div class="input-group"><input type="datetime-local" value="2019-11-05T18:18" id="example-input2-group1" name="schedule_date[]" class="form-control" placeholder="Email"><span  id="remScnt"class="input-group-addon"><i class="fa fa-minus"></i></span></div></div></div>').appendTo(scntDiv);
	        i++;
	        return false;
	    });
	    
	    $('#more-xtra').on('click','#remScnt' ,function(e) { 
	    	// alert(i);
	        // if( i > 2 ) {
	        	$('#more-xtra #extr:last').remove();
	            i--;

	        // }
	        e.preventDefault();
	        return false;
	    });
	});

	</script>
                                   <!-- product sales  -->
                            <!-- ============================================================== -->
                            <!-- ============================================================== -->
                            <!-- end product sales  -->
                            <!-- ============================================================== -->
                        </div>

                        <div class="row">
                            <!-- ============================================================== -->
                            <!-- sales  -->
                            <!-- ============================================================== -->
                            <!-- ============================================================== -->
                            <!-- end sales  -->
                            <!-- ============================================================== -->
                            <!-- ============================================================== -->
                            <!-- new customer  -->
                            <!-- ============================================================== -->
                            <!-- ============================================================== -->
                            <!-- end new customer  -->
                            <!-- ============================================================== -->
                            <!-- ============================================================== -->
                            <!-- visitor  -->
                            <!-- ============================================================== -->
                            <!-- ============================================================== -->
                            <!-- end visitor  -->
                            <!-- ============================================================== -->
                            <!-- ============================================================== -->
                            <!-- total orders  -->
                            <!-- ============================================================== -->
                            <!-- ============================================================== -->
                            <!-- end total orders  -->
                            <!-- ============================================================== -->
                        </div>
                        <div class="row">
                            <!-- ============================================================== -->
                            <!-- total revenue  -->
                            <!-- ============================================================== -->
  
                            
                            <!-- ============================================================== -->
                            <!-- ============================================================== -->
                            <!-- category revenue  -->
                            <!-- ============================================================== -->
                            <!-- ============================================================== -->
                            <!-- end category revenue  -->
                            <!-- ============================================================== -->
                        </div>
                        <div class="row">
                          <!-- ============================================================== -->
                            <!-- end sales traffice source  -->
                            <!-- ============================================================== -->
                            <!-- ============================================================== -->
                            <!-- sales traffic country source  -->
                            <!-- ============================================================== -->
                            <!-- ============================================================== -->
                            <!-- end sales traffice country source  -->
                            <!-- ============================================================== -->
                        </div>
                    </div>
                </div>
            </div>
            <!-- ============================================================== -->
            <!-- footer -->
            <!-- ============================================================== -->
            <?php include('../../inc/footer1.php');?>
            <!-- ============================================================== -->
            <!-- end footer -->
            <!-- ============================================================== -->
        </div>
        <!-- ============================================================== -->
        <!-- end wrapper  -->
        <!-- ============================================================== -->
    </div>
    <!-- ============================================================== -->
    <!-- end main wrapper  -->
    <!-- ============================================================== -->
    <!-- Optional JavaScript -->
    <!-- jquery 3.3.1 -->
    <script src="../../assets/vendor/jquery/jquery-3.3.1.min.js"></script>
    <!-- bootstap bundle js -->
    <script src="../../assets/vendor/bootstrap/js/bootstrap.bundle.js"></script>
    <!-- slimscroll js -->
    <script src="../../assets/vendor/slimscroll/jquery.slimscroll.js"></script>
    <!-- main js -->
    <script src="../../assets/libs/js/main-js.js"></script>
    <!-- chart chartist js -->
    <script src="../../assets/vendor/charts/chartist-bundle/chartist.min.js"></script>
    <!-- sparkline js -->
    <script src="../../assets/vendor/charts/sparkline/jquery.sparkline.js"></script>
    <!-- morris js -->
    <script src="../../assets/vendor/charts/morris-bundle/raphael.min.js"></script>
    <script src="../../assets/vendor/charts/morris-bundle/morris.js"></script>
    <!-- chart c3 js -->
    <script src="../../assets/vendor/charts/c3charts/c3.min.js"></script>
    <script src="../../assets/vendor/charts/c3charts/d3-5.4.0.min.js"></script>
    <script src="../../assets/vendor/charts/c3charts/C3chartjs.js"></script>
    <script src="../../assets/libs/js/dashboard-ecommerce.js"></script>
</body>
 
</html>