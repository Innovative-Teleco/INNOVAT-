<?php
//Server Address
$SmtpServer="mail.epins.com.ng"; //example mail.xxxxxxx.com
$SmtpPort="25"; //do not change this
$SmtpUser="support@epins.com.ng"; //example support@xxxxxx.com
$SmtpPass="Control123!"; // example: the password for the email account support@xxxxxxx.com

?>