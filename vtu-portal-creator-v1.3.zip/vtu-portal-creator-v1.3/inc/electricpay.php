<?php
$qryApi = mysqli_query($conn,"SELECT * FROM api_setting");
$apidata = mysqli_fetch_array($qryApi);

$apikey = $apidata['APIkey']; //email address()


$host = "https://epins.com.ng/api/electric?apikey=$apikey&service=$network&accountno=$iuc&vcode=$variation_code&amount=$amount&ref=$requestId ";


//Initialize cURL.
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $host);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);

$dataR = curl_exec($ch);
$result = json_decode($dataR);

//Close the cURL handle.
curl_close($ch);


$resp = json_decode($dataR);

?>